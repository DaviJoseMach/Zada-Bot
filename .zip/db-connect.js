const {createClient} = require ('@supabase/supabase-js')

const SUPABASE_URL = 'https://fruyegidzfyzsqntocrk.supabase.co';
const SUPABASE_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImZydXllZ2lkemZ5enNxbnRvY3JrIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MzQ2MjgyNDIsImV4cCI6MjA1MDIwNDI0Mn0.qvlxTEIoIGybIuk20bMredBofSVYLvIVKLusJizmilk'

const supabase = createClient(SUPABASE_URL, SUPABASE_KEY)

module.exports = supabase;